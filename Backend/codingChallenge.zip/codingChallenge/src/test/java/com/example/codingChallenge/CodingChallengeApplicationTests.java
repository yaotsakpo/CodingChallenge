package com.example.codingChallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
