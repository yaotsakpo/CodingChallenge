package com.example.codingChallenge.controller;

import com.example.codingChallenge.model.Transaction;
import com.example.codingChallenge.service.RewardPointsService;
import com.example.codingChallenge.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/reward-points")
public class RewardPointsController {

    @Autowired
    private RewardPointsService rewardPointsService;

    @Autowired
    private TransactionService transactionService;

    @GetMapping("/{customerId}")
    public ResponseEntity<Integer> calculateRewardPoints(@PathVariable Long customerId) {
        int rewardPoints = rewardPointsService.calculateRewardPoints(customerId);
        return ResponseEntity.ok(rewardPoints);
    }

    @GetMapping
    public Map<Long, Integer> calculateRewardPointsForAllCustomers() {
        List<Transaction> allTransactions = transactionService.getAllTransactions();
        Map<Long, Integer> rewardPointsMap = new HashMap<>();

        for (Transaction transaction : allTransactions) {
            Long customerId = transaction.getCustomerId();
            int rewardPoints = rewardPointsMap.getOrDefault(customerId, 0);
            rewardPoints += rewardPointsService.calculateRewardPointsForTransaction(transaction.getAmount());
            rewardPointsMap.put(customerId, rewardPoints);
        }

        return rewardPointsMap;
    }
}

